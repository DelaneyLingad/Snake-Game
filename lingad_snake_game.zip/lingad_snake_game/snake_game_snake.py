"""
PROJECT 1 - THE GAME OF SNAKE
(Application of Doubly-Linked List)

File Name: lingad_project1_snake
Author: Del Lingad
Date: September 15, 2025
Course: COMP1353 (Data Struct. & Algorithms I)
Assignment: Project 1 - The Game of Snake
Collaborators: None
Internet Sources: None
"""
import dudraw as dd

def snake_base(dll): # initializes the base of the snake
    """
    Creates the base nodes of the snake
    
    parameters:
        dll: A doubly linked list
    """
    snake_head = [10, 5] # head of the snake at the center of the canvas
    body_1 = [10, 4] # first body block behind the head of the snake
    body_2 = [10, 3] # second body block

    # create and add nodes to the doubly linked list for the different body parts of the snake
    dll.add_first(snake_head)
    dll.add_last(body_1)
    dll.add_last(body_2)

def draw_snake(dll):
    """
    Takes in a a Doubly Linked List to draw the Snake.
    
    parameters:
        dll: Doubly Linked List
    """
    dd.set_pen_color(dd.BLACK) # make the pen color dark green
    temp = dll.head.next # set temp as the first real node in the list
    while temp is not dll.tail: # iterate through the doubly linked list, drawing each part of the snake
        dd.filled_square(temp.value[0]+0.5, temp.value[1]+0.5, 0.5) # add 0.5 so it aligns with the dudraw canvas
        temp = temp.next