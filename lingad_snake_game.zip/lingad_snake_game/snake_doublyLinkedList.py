"""
PROJECT 1 - THE GAME OF SNAKE
(Application of Doubly-Linked List)

File Name: lingad_project1_snake
Author: Del Lingad
Date: September 15, 2025
Course: COMP1353 (Data Struct. & Algorithms I)
Assignment: Project 1 - The Game of Snake
Collaborators: None
Internet Sources: None
"""

class Node:
    def __init__(self, value=None):
        self.value = value
        self.prev = None
        self.next = None

    def __str__(self) -> str:
        return str(self.value)

    def __repr__(self) -> str:
        return self.__str__()

    def __eq__(self, other) -> bool:
        return self.value == other.value

class DoublyLinkedList:
    
    def __init__(self): # initializes an empty list
        self.head = Node()   # sentinel node at the beginning
        self.tail = Node()   # sentinel node at the end
        # sentinel nodes point to each other
        self.head.next = self.tail
        self.tail.prev = self.head
        self.size = 0

    def __str__(self) -> str: # returns a string representing the list
        if self.head.next is self.tail:
            return "[]"
        else:
            current = self.head.next # start at the first node
            result = "["
            while current.next is not self.tail: # iterate through the entirety of the list
                result += str(current) + " "
                current = current.next
            result += str(current) + "]"
            return result

    def is_empty(self): # returns True if the list is empty, False otherwise
        if self.size == 0:
            return True # return True if the size of the list is 0 (empty list)
        else:
            return False # return False otherwise

    def get_size(self): # returns the size of the list
        return self.size
    
    def add_first(self, v): # adds v at the head of the list
        newNode = Node(v)
        right = self.head.next # save the address of the node after head
        self.head.next = newNode # adds v (newNode) to the front of the list
        newNode.next = right # connect newNode to the next node in the list
        right.prev = newNode # connect the previous reference to the newNode
        newNode.prev = self.head # connect the previous reference of the newNode to the head
        
        self.size += 1 # increment size of list by 1
    
    def add_last(self, v): # adds v at the end of the list
        newNode = Node(v) 
        left = self.tail.prev # save the address of the original last node
        self.tail.prev = newNode # adds v (newNode) to the end of the list
        newNode.prev = left # connect newNode to the previous node in the list
        left.next = newNode # connect the next reference to the newNode
        newNode.next = self.tail # connect the next reference of the newNode to the tail

        self.size += 1 # increment size of list by 1

    def remove_first(self): # removes and returns the first value in the list
        value_to_return = self.head.next.value # save the value of the node to be removed
        self.head.next = self.head.next.next # set the "next" of head to the second node in the list
        self.head.next.prev = self.head # set the "prev" of the second node in the list to head

        self.size -= 1 # decrease size of list by 1
        return value_to_return # return original first value from the list

    def remove_last(self): # removes and returns the last value in the list
        value_to_return = self.tail.prev.value # save the value of the node to  be removed
        self.tail.prev = self.tail.prev.prev # set the "prev" of tail to the second to last node in the list
        self.tail.prev.next = self.tail # set the "next" of the second to last node in the list to tail

        self.size -= 1 # decrease size of list by 1
        return value_to_return # return original last value from the list

    def first(self): # returns the first value in the list
        return self.head.next.value
    
    def last(self): # returns the last value in the list
        return self.tail.prev.value
    
    def search(self, value): # returns the index of the value if found and -1 otherwise
        temp = self.head.next # keep track of the node
        index = 0 # keep track of the index
        while temp is not None: # traverse through the list
            if temp.value == value: # if the value is found, return the index
                return index
            else:
                temp = temp.next # go to the next node in the list
                index += 1 # increase the index by 1
        return -1 # if the value is not found, return -1
    
    def get(self, index: int): # returns the value at index
        temp = self.head.next
        for _ in range(index): # iterate through the list to the desired index
            temp = temp.next
        return temp.value
        
def dll_tester():
    # create a DoublyLinkedList
    test_list = DoublyLinkedList()
    
    #testing list creation
    assert test_list.get_size()==0,   'list should be empty to start!'
    
    #testing add_first
    test_list.add_first(1)
    assert test_list.first() == 1, 'add_first needs adjustment!'
    assert test_list.last() == 1, 'add_first needs adjustment!'
    assert test_list.get_size() == 1 ,    'add_first needs adjustment!'
    test_list.add_first(2)
    assert test_list.first() == 2, 'add_first needs adjustment!'
    assert test_list.last() == 1, 'add_first needs adjustment!'
    assert test_list.get_size() == 2, 'add_first needs adjustment!'
    
    #testing add_last
    test_list.add_last(3)
    assert test_list.first() == 2,'add_last needs adjustment!'
    assert test_list.last() == 3, 'add_last needs adjustment!'
    assert test_list.get_size() == 3, 'add_last needs adjustment!'

    #test remove_first
    assert test_list.remove_first() == 2, 'remove_first needs adjustment!'
    assert test_list.first() == 1, 'remove_first needs adjustment!'
    assert test_list.last() == 3, 'remove_first needs adjustment!'
    assert test_list.get_size() == 2, 'remove_first needs adjustment!'

    #test remove_last
    assert test_list.remove_last() == 3, 'remove_last needs adjustment!'
    assert test_list.first() == 1, 'remove_last needs adjustment!'
    assert test_list.last() == 1, 'remove_last needs adjustment!'
    assert test_list.get_size() == 1, 'remove_last needs adjustment!'

    while not test_list.is_empty():
        test_list.remove_first()

    assert test_list.get_size() == 0, 'list should be empty after removing all values'    

    for i in range(10):
        test_list.add_last(i+1)
    #test get method
    assert test_list.get(0) == 1, 'get(0) should return the element at first index'
    assert test_list.get(5) == 6, 'get(1) should return the element at index 1'
    assert test_list.get(9) == 10, 'get(9) should return the element at last index'

    print('All tests passed!')

def main():
    dll_tester()

if __name__ == "__main__":
    main()

# snake should have it's own file
# linked lists should have its own file