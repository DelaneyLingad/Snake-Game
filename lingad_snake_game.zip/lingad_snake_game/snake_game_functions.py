"""
PROJECT 1 - THE GAME OF SNAKE
(Application of Doubly-Linked List)

File Name: lingad_project1_snake
Author: Del Lingad
Date: September 15, 2025
Course: COMP1353 (Data Struct. & Algorithms I)
Assignment: Project 1 - The Game of Snake
Collaborators: None
Internet Sources: None
"""

# MOVEMENT OF THE SNAKE
def move_up(dll):
    """
    Moves the snake upwards in the dudraw canvas by updating the y positions.
    
    parameters:
        dll: Doubly linked list
    """
    temp = dll.head.next # track the current node

    old_y = temp.value[1] # saves the original y coordinate of the current body part
    old_x = temp.value[0] # saves the original x coordinate of the current body part

    # begin by updating position of the head of the snake
    temp.value[1] += 1 # add 1 to the y-coordinate of the head of the snake

    temp = temp.next # go to the next node

    while temp is not dll.tail: # iterate through the whole list
            
        if temp.value[1] is None: # return the doubly linked to prevent NoneType error
            return dll
        
        new_y = temp.value[1] # save the current value of y before changing it
        new_x = temp.value[0] # save the current value of x before changing it
        temp.value[1] = old_y # update the y-coordinate to the previous y-coordinate of the node ("body part") in front of it
        temp.value[0] = old_x
        old_y = new_y # update the original y coordinate
        old_x = new_x # update the original x coordinate
        temp = temp.next # go to the next node
            
    return dll

def move_down(dll):
    """
    Moves the snake down in the dudraw canvas by updating the y positions.
    
    parameters:
        dll: Doubly linked list
    """
    temp = dll.head.next # track the current node

    old_y = temp.value[1] # saves the original y coordinate of the current body part
    old_x = temp.value[0] # saves the original x coordinate of the current bddy part

    # begin by updating position of the head of the snake
    temp.value[1] -= 1 # subtract 1 from the y-coordinate of the head of the snake

    temp = temp.next # go to the next node

    while temp is not dll.tail: # iterate through the whole list
            
        if temp.value[1] is None: # return the doubly linked to prevent NoneType error
            return dll
        
        new_y = temp.value[1] # save the current value of y before changing it
        new_x = temp.value[0] # save the current value of x before changing it
        temp.value[1] = old_y # update the y-coordinate to the previous y-coordinate of the node ("body part") in front of it
        temp.value[0] = old_x # update the x-coordinate to the previous x-coordinate of the node ("body part") in front of it
        old_y = new_y # update the original y-coordinate
        old_x = new_x # update the original x-coordinate
        temp = temp.next # go to the next node
            
    return dll

def move_right(dll):
    """
    Moves the snake to the right in the dudraw canvas by updating the x positions.
    
    parameters:
        dll: Doubly linked list
    """
    temp = dll.head.next # track the current node

    old_x = temp.value[0] # saves the original x coordinate of the current body part
    old_y = temp.value[1] # saves the original y coordinate of the current body part

    # begin by updating position of the head of the snake
    temp.value[0] += 1 # add 1 to the x-coordinate of the head of the snake

    temp = temp.next # go to the next node

    while temp is not dll.tail: # iterate through the whole list
            
        if temp.value[0] is None: # return the doubly linked to prevent NoneType error
            return dll
        
        new_x = temp.value[0] # save the current value of y before changing it
        new_y = temp.value[1] # save the current value of x before changing it
        temp.value[0] = old_x # update the x-coordinate to the previous x-coordinate of the node ("body part") in front of it
        temp.value[1] = old_y # update the y-coordinate to the previous y-coordinate of the node ("body part") in front of it
        old_x = new_x # update the old x-coordinate
        old_y = new_y # update the old y-coordinate

        temp = temp.next # go to the next node
            
    return dll

def move_left(dll):
    """
    Moves the snake to the left in the dudraw canvas by updating the x positions.
    
    parameters:
        dll: Doubly linked list
    """
    temp = dll.head.next # track the current node

    old_x = temp.value[0] # saves the original x coordinate of the current body part
    old_y = temp.value[1] # saves the original y coordinate of the current body part

    # begin by updating position of the head of the snake
    temp.value[0] -= 1 # subtract 1 from the x-coordinate of the head of the snake

    temp = temp.next # go to the next node

    while temp is not dll.tail: # iterate through the whole list
            
        if temp.value[0] is None: # return the doubly linked to prevent NoneType error
            return dll
        
        new_x = temp.value[0] # save the current value of y before changing it
        new_y = temp.value[1] # save the current value of x before changing it
        temp.value[0] = old_x # update the x-coordinate to the previous x-coordinate of the node ("body part") in front of it
        temp.value[1] = old_y # update the y-coordinate to the previous y-coordinate of the node ("body part") in front of it
        old_x = new_x # update the old x-coordinate
        old_y = new_y # update the old y-coordinate

        temp = temp.next # go to the next node
    
    return dll

# CHECK IF THE SNAKE HITS THE BORDER OR ITSELF
def hit_border(dll)->bool:
    """
    Checks if the snake hits the border with the x, y coordinate of the head of the snake.
    Return True if the border is hit, False otherwise.
    
    parameters:
        dll: Doubly linked list
    """
    x = dll.head.next.value[0] # the x coordinate of the head of the snake
    y = dll.head.next.value[1] # the y coordinate of the head of the snake
    # the draw snake function is offset by 0.5 px
    if x <= 0 or x >= 19 or y <= 0 or y >= 19: # if the x or y coordinate go beyond the border return True
        return True

def hit_snake(dll)->bool:
    """
    Check if the snake runs into itself.
    Return True if the snake runs into itself, False otherwise.
    
    parameters:
        dll: Doubly linked list
    """    
    head_x = dll.head.next.value[0]
    head_y = dll.head.next.value[1]

    temp = dll.head.next.next # the first body part of the snake that is not the head
    while temp is not dll.tail:
        if head_x == temp.value[0] and head_y == temp.value[1]: # see if the head coordinates match of the other coordinates in the doubly linked list
            return True
        temp = temp.next # go to the next node
    return False

# FRUIT FUNCTIONS
def fruit_eaten(dll, x=int, y=int)->bool:
    """
    Checks to see if the snake ate the apple.
    Return True if the apple is eaten, False otherwise.
    
    parameters:
        dll: Doubly linked list
        x: The x-coordinate of the fruit
        y: The y-coordinate of the fruit
    """
    snake_head = dll.head.next # reference to the head of the snake
    if x == snake_head.value[0] and y == snake_head.value[1]: # check if the x, y coordinates of the fruit match the x, y coordinates of the snake head
        return True