"""
Scalable Drawing of an Apple

File Name: snake_game_fruit
Date: September 18, 2025
Course: COMP1353
Assignment: Project 1 - Snake Game
Name: Del Lingad
Internet Sources: None
"""

import dudraw as dd

def apple(x = float, y = float, w = float, h = float):
    """
    Draws an apple.

    parameters:
        x: x coordinate of the bottom left corner of the apple
        y: y coordinate of the lower left corner of the apple
        w: width
        h: height

    Mostly fills a [0,1]x[0,1] region on a dudraw canvas.
    """

    # draw the apple
    dd.set_pen_color_rgb(230, 43, 43) # make pen color red
    dd.filled_ellipse(x+w*0.5, y+h*0.45, w*0.5, h*0.45)

    # draw the stem
    dd.set_pen_color_rgb(117, 72, 14) # make pen color brown
    dd.filled_rectangle(x+w*0.5, y+h*0.85, w*0.025, h*0.1)