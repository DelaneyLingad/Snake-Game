"""
PROJECT 1 - THE GAME OF SNAKE
(Application of Doubly-Linked List)

File Name: lingad_project1_snake
Author: Del Lingad
Date: September 15, 2025
Course: COMP1353 (Data Struct. & Algorithms I)
Assignment: Project 1 - The Game of Snake
Collaborators: None
Internet Sources: None
"""

import dudraw as dd

def create_canvas():
    """
    Draws a 500px x 500 px light green dudraw canvas. 
    The x-axis and y-axis are scaled to (0, 25).
    """
    dd.set_canvas_size(500, 500) # 500 x 500 px grid
    # scale the x and y axis
    dd.set_x_scale(0,20)
    dd.set_y_scale(0,20)

    dd.clear_rgb(200, 255, 183) # make the background light green


def draw_canvas():

    dd.clear_rgb(200, 255, 183) # make the background light green

    # create the checkerboard pattern
    x = 0.5 # set original x position
    y = 0.5 # set original y position
    half_width = 0.5 # half width of the square
    for row in range(20):
        if row%2 == 0: # if the row is even start at the bottom left corner
            x = 0.5
        else: # if the row is odd offset it by 1 square
            x = 1.5
        for col in range(20):
            if col%2 == 0: # do every other column
                dd.set_pen_color_rgb(167, 227, 148)
                dd.filled_square(x, y, half_width)
            x += 1 # move the square over by 1
        y += 1 # move up the y position
            