"""
PROJECT 1 - THE GAME OF SNAKE
(Application of Doubly-Linked List)

File Name: lingad_project1_snake
Author: Del Lingad
Date: September 15, 2025
Course: COMP1353 (Data Struct. & Algorithms I)
Assignment: Project 1 - The Game of Snake
Collaborators: None
Internet Sources: None
"""

import dudraw as dd
import random
import snake_doublyLinkedList as sdll
import snake_game_background as background
import snake_game_fruit as fruit
import snake_game_snake as snake
import snake_game_functions as functions

def main():
    # Create the basic elements of the game
    background.create_canvas() # create the dudraw canvas
    background.draw_canvas()
    dll = sdll.DoublyLinkedList() # initialize a doubly linked list
    snake.snake_base(dll) # add the first elements of the snake to the doubly linked list

    run_game = True # game begins
    limit = 20 # number of frames to allow to pass before snake moves
    timer = 0  # a timer to keep track of number of frames that passed
    direction = "up" # the default direction of the snake when the game starts is "up"

    # initalize the coordinates of the fruit
    fruit_x = random.randint(0, 19)
    fruit_y = random.randint(0, 19)

    while run_game is not False:
        timer += 1

        keys = dd.keys_pressed() # track the keys pressed by the user

        # process keyboard presses and associated direction
        if "w" in keys: # "w" associated with direction "up"
            direction = "up"
        if "s" in keys: # "s" associated with direction "down" 
            direction = "down"
        if "a" in keys: # "a" associated with direction "left"
            direction = "left"
        if "d" in keys: # "d" associated with direction "right"
            direction = "right"

        if timer == limit:
            timer = 0

            # change the direction of the snake only when a new key is pressed
            if direction == "up":
                functions.move_up(dll)
            elif direction == "down":
                functions.move_down(dll)
            elif direction == "left":
                functions.move_left(dll)
            elif direction == "right":
                functions.move_right(dll)

            # draw and move the snake
            # check if the snake hit the border
            border_hit = functions.hit_border(dll)
            if border_hit == True:
                run_game = False

            background.draw_canvas() # clear the background
            snake.draw_snake(dll) # draw the snake

            # check to see if snake ate the fruit
            fruit.apple(fruit_x, fruit_y, 1, 1)
            eaten = functions.fruit_eaten(dll, fruit_x, fruit_y) # check if the fruit has been eaten
            if eaten == True:
                fruit_x = random.randint(0, 19)
                fruit_y = random.randint(0, 19)
                dll.add_last([dll.tail.prev.value[0]-1, dll.tail.prev.value[1]-1])

            # check if the snake self intersects
            intersects = functions.hit_snake(dll)
            if intersects == True:
                run_game = False

        dd.show(20)
        
    # show the game over screen
    dd.set_pen_color(dd.RED)
    dd.text(10, 10, "GAME OVER")
    dd.show(float('inf'))

if __name__ == "__main__":
    main()